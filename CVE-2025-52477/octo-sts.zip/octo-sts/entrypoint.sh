#!/bin/sh
if [ ! -f /app/secrets/github_app_key ]; then
  openssl genrsa -out /app/secrets/github_app_key 2048
fi
exec ./octo-sts