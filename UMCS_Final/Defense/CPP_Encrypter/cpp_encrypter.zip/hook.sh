#!/bin/sh

echo $FLAG > /srv/app/flag
