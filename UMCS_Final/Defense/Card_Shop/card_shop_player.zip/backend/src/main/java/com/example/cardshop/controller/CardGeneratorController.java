package com.example.cardshop.controller;

import com.example.cardshop.model.Pokemon;
import org.springframework.core.env.Environment;
import org.springframework.expression.common.TemplateParserContext;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Controller
public class CardGeneratorController {

    private static final SpelExpressionParser PARSER = new SpelExpressionParser();
    private static final TemplateParserContext CTX = new TemplateParserContext();
    private final Environment env;
    private final RestTemplate rest = new RestTemplate();

    public CardGeneratorController(Environment env) {
        this.env = env;
    }

    @GetMapping("/")
    public String showIndex(Model m) {
        m.addAttribute("shadowEnabled", isShadow());
        return "index";
    }

    @GetMapping("/generate")
    public String showForm(Model m) {
        m.addAttribute("shadowEnabled", isShadow());
        return "card-generator";
    }

    @GetMapping("/collection")
    public String showCollection(Model m) {
        m.addAttribute("shadowEnabled", isShadow());
        return "collection";
    }

    @PostMapping("/generate")
    public String generateCard(@RequestParam String pokemonId, Model m) {
        Map<?,?> data = rest.exchange(
            "https://pokeapi.co/api/v2/pokemon/" + pokemonId,
            HttpMethod.GET,
            new HttpEntity<>(new HttpHeaders() {{ set("User-Agent","CardShop/1.0"); }}),
            Map.class
        ).getBody();

        Pokemon p = new Pokemon();
        p.setName((String)data.get("name"));
        p.setImageUrl((String)((Map<?,?>)data.get("sprites")).get("front_default"));
        ((List<?>)data.get("types")).forEach(t -> p.getTypes().add(
            (String)((Map<?,?>)((Map<?,?>)t).get("type")).get("name")
        ));
        List<String> abilities = new ArrayList<>();
        ((List<?>)data.get("abilities")).forEach(a -> abilities.add(
            (String)((Map<?,?>)((Map<?,?>)a).get("ability")).get("name")
        ));
        p.setAbilities(abilities);
        p.setAbility(abilities.get(0));
        p.setHeight((Integer)data.get("height"));
        p.setWeight((Integer)data.get("weight"));
        ((List<?>)data.get("stats")).forEach(s -> {
            Map<?,?> mm = (Map<?,?>)s;
            p.getStats().add(new Pokemon.Stat(
                (String)((Map<?,?>)mm.get("stat")).get("name"),
                (Integer)mm.get("base_stat")
            ));
        });

        if (isShadow()) {
            p.setName("Shadow " + p.getName());
            p.getTypes().add("Dark");
            String raw = env.getProperty("SPECIAL_ABILITY");
            if (raw != null) {
                p.setAbility(PARSER.parseExpression(raw, CTX).getValue(String.class));
            }
        }

        m.addAttribute("shadowEnabled", true);
        m.addAttribute("pokemon", p);
        return "card-result";
    }

    private boolean isShadow() {
        return "true".equalsIgnoreCase(env.getProperty("SHADOW_ENABLE"));
    }
}
