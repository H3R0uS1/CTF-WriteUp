package com.example.cardshop.controller;

import com.example.cardshop.model.Pokemon;
import com.example.cardshop.service.PokemonService;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

@RestController
@RequestMapping("/pokemon")
public class PokemonController {
    
    @Autowired
    private RestTemplate restTemplate;
    
    @Autowired
    private PokemonService pokemonService;
    
    private static final String POKEAPI_BASE_URL = "https://pokeapi.co/api/v2/pokemon/";
    
    @GetMapping("/{id}")
    public ResponseEntity<Pokemon> getPokemon(@PathVariable int id) {
        try {
            Pokemon pokemon = pokemonService.getPokemonById(id);
            if (pokemon == null) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok(pokemon);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/{id}/abilities")
    public ResponseEntity<List<String>> showAbilities(@PathVariable int id) {
        try {
            Pokemon pokemon = pokemonService.getPokemonById(id);
            if (pokemon == null) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok(pokemon.getAbilities());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
} 