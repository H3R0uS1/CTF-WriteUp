package com.example.cardshop.model;

import java.util.ArrayList;
import java.util.List;

public class Pokemon {
    private Long id;
    private String name;
    private String type;
    private int level;
    private String imageUrl;
    private List<String> types = new ArrayList<>();
    private List<String> abilities = new ArrayList<>();
    private List<Stat> stats = new ArrayList<>();
    private int height;
    private int weight;
    private String ability;
    private boolean hasMegaForm;

    public static class Stat {
        private String name;
        private int baseStat;

        public Stat(String name, int baseStat) {
            this.name = name;
            this.baseStat = baseStat;
        }

        public String getName() {
            return name;
        }

        public int getBaseStat() {
            return baseStat;
        }
    }

    public Pokemon() {
    }

    public Pokemon(Long id, String name, String type, int level) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.level = level;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public List<String> getTypes() {
        return types;
    }

    public void setTypes(List<String> types) {
        this.types = types;
    }

    public List<String> getAbilities() {
        return abilities;
    }

    public void setAbilities(List<String> abilities) {
        this.abilities = abilities;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public List<Stat> getStats() {
        return stats;
    }

    public void setStats(List<Stat> stats) {
        this.stats = stats;
    }

    public String getAbility() {
        return ability;
    }

    public void setAbility(String ability) {
        this.ability = ability;
    }

    public boolean isHasMegaForm() {
        return hasMegaForm;
    }

    public void setHasMegaForm(boolean hasMegaForm) {
        this.hasMegaForm = hasMegaForm;
    }
} 