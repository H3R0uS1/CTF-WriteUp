package com.example.cardshop.service;

import com.example.cardshop.model.Pokemon;
import com.example.cardshop.model.Pokemon.Stat;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

@Service
public class PokemonService {
    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final String POKE_API_URL = "https://pokeapi.co/api/v2/pokemon/";

    public Pokemon getPokemonById(int id) {
        String url = POKE_API_URL + id;
        
        HttpHeaders headers = new HttpHeaders();
        headers.set("User-Agent", "PokemonCardShop/1.0");
        
        RequestEntity<Void> requestEntity = new RequestEntity<>(headers, HttpMethod.GET, URI.create(url));
    
        ResponseEntity<String> response = restTemplate.exchange(requestEntity, String.class);
        String responseBody = response.getBody();
        
        try {
            JsonNode root = objectMapper.readTree(responseBody);
            Pokemon pokemon = new Pokemon();
            
            pokemon.setId(root.get("id").asLong());
            pokemon.setName(root.get("name").asText());
            pokemon.setImageUrl(root.get("sprites").get("other").get("official-artwork").get("front_default").asText());
            
            // Get types
            List<String> types = new ArrayList<>();
            root.get("types").forEach(typeNode -> 
                types.add(typeNode.get("type").get("name").asText())
            );
            pokemon.setTypes(types);
            
            // Get abilities
            List<String> abilities = new ArrayList<>();
            root.get("abilities").forEach(abilityNode -> 
                abilities.add(abilityNode.get("ability").get("name").asText())
            );
            pokemon.setAbilities(abilities);
            
            // Get stats
            List<Stat> stats = new ArrayList<>();
            root.get("stats").forEach(statNode -> {
                String statName = statNode.get("stat").get("name").asText();
                int baseStat = statNode.get("base_stat").asInt();
                stats.add(new Stat(statName, baseStat));
            });
            pokemon.setStats(stats);
            
            pokemon.setHeight(root.get("height").asInt());
            pokemon.setWeight(root.get("weight").asInt());
            
            return pokemon;
        } catch (Exception e) {
            throw new RuntimeException("Error parsing Pokemon data", e);
        }
    }
} 