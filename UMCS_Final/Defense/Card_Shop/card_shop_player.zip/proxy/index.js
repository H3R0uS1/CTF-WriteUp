const fastify = require('fastify')()
const axios = require('axios')
const getRawBody = require('raw-body')
fastify.register(require('@fastify/formbody'))

const BE = 'http://localhost:8080'

async function forward(req, reply, method, path) {
    const headers = { ...req.headers }
    delete headers.host

    let data
    if (headers['content-type']?.includes('application/x-www-form-urlencoded') &&
        typeof req.body === 'object') {
        data = new URLSearchParams(req.body).toString()
    } else if (req.body !== undefined) {
        data = typeof req.body === 'object' ? JSON.stringify(req.body) : req.body
        headers['content-type'] = 'application/json'
    } else {
        data = (await getRawBody(req.raw).catch(() => null))?.toString()
    }

    delete headers['content-length']

    const res = await axios({
        method,
        url: BE + path,
        data,
        headers,
        responseType: 'arraybuffer',
        validateStatus: () => true
    })

    reply.status(res.status)
    Object.entries(res.headers).forEach(([k, v]) => reply.header(k, v))
    reply.send(res.data)
}

fastify.get('/', (r, s) => forward(r, s, 'GET', '/'))
fastify.get('/generate', (r, s) => forward(r, s, 'GET', '/generate'))
fastify.post('/generate', (r, s) => forward(r, s, 'POST', '/generate'))
fastify.get('/collection', (r, s) => forward(r, s, 'GET', '/collection'))
fastify.get('/pokemon', (r, s) => {
    const id = r.query.id || ''
    return forward(r, s, 'GET', `/pokemon/${id}`)
})
fastify.post('/abilities', (r, s) => {
    const id = r.body.id || ''
    return forward(r, s, 'POST', `/pokemon/${id}/abilities`)
})

fastify.listen({ port: 3000, host: '0.0.0.0' })
