<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CatGalleryController extends Controller
{
    public function home()
    {
        return view('cat-gallery.home');
    }

    public function about()
    {
        return view('cat-gallery.about');
    }

    public function gallery()
    {
        $cats = [
            ['name' => 'Neo', 'url' => 'https://placecats.com/neo/300/200'],
            ['name' => 'Millie', 'url' => 'https://placecats.com/millie/300/200'],
            ['name' => 'Bella', 'url' => 'https://placecats.com/bella/300/200'],
            ['name' => 'Neo Banana', 'url' => 'https://placecats.com/neo_banana/300/200'],
            ['name' => 'Millie & Neo', 'url' => 'https://placecats.com/millie_neo/300/200'],
            ['name' => 'Grayscale', 'url' => 'https://placecats.com/g/300/200'],
        ];

        return view('cat-gallery.gallery', compact('cats'));
    }
} 