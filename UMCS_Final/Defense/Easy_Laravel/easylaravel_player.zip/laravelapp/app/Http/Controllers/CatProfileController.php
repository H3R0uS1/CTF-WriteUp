<?php

namespace App\Http\Controllers;

use App\Models\Cat;
use App\Models\CatPhoto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;

class CatProfileController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $cats = Cat::where('is_public', true)
            ->orWhere('owner_id', Auth::id())
            ->with('photos')
            ->get();
        
        return view('cat-gallery.profiles.index', compact('cats'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('cat-gallery.profiles.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'breed' => 'nullable|string|max:255',
            'age' => 'nullable|integer|min:0',
            'description' => 'nullable|string',
            'profile_picture' => 'nullable|image|max:2048',
            'photos.*' => 'nullable|image|max:2048',
            'captions.*' => 'nullable|string|max:255',
        ]);

        $cat = new Cat($validated);
        $cat->owner_id = Auth::id();
        $cat->is_public = true;

        if ($request->hasFile('profile_picture')) {
            $path = $request->file('profile_picture')->store('cat-profiles', 'public');
            $cat->profile_picture = $path;
        }

        $cat->save();

        if ($request->hasFile('photos')) {
            foreach ($request->file('photos') as $index => $photo) {
                $path = $photo->store('cat-photos', 'public');
                $cat->photos()->create([
                    'photo_path' => $path,
                    'caption' => $validated['captions'][$index] ?? null,
                    'is_primary' => $index === 0,
                ]);
            }
        }

        return redirect()->route('cat-profiles.index')
            ->with('success', 'Cat profile created successfully!');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Cat $cat)
    {
        if ($cat->owner_id !== Auth::id()) {
            abort(403);
        }

        $cat->load('photos');
        return view('cat-gallery.profiles.edit', compact('cat'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Cat $cat)
    {
        if ($cat->owner_id !== Auth::id()) {
            abort(403);
        }

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'breed' => 'nullable|string|max:255',
            'age' => 'nullable|integer|min:0',
            'description' => 'nullable|string',
            'is_public' => 'boolean',
            'profile_picture' => 'nullable|image|max:2048',
            'photos.*' => 'nullable|image|max:2048',
            'captions.*' => 'nullable|string|max:255',
        ]);

        $cat->update($validated);

        if ($request->hasFile('profile_picture')) {
            if ($cat->profile_picture) {
                Storage::disk('public')->delete($cat->profile_picture);
            }
            $path = $request->file('profile_picture')->store('cat-profiles', 'public');
            $cat->profile_picture = $path;
            $cat->save();
        }

        if ($request->hasFile('photos')) {
            foreach ($request->file('photos') as $index => $photo) {
                $path = $photo->store('cat-photos', 'public');
                $cat->photos()->create([
                    'photo_path' => $path,
                    'caption' => $validated['captions'][$index] ?? null,
                    'is_primary' => false,
                ]);
            }
        }

        return redirect()->route('cat-profiles.show', $cat)
            ->with('success', 'Cat profile updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Cat $cat)
    {
        if ($cat->owner_id !== Auth::id()) {
            abort(403);
        }

        if ($cat->profile_picture) {
            Storage::disk('public')->delete($cat->profile_picture);
        }

        foreach ($cat->photos as $photo) {
            Storage::disk('public')->delete($photo->photo_path);
        }

        $cat->delete();

        return redirect()->route('cat-profiles.index')
            ->with('success', 'Cat profile deleted successfully!');
    }
}
