<?php

namespace App\Livewire;

use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\Attributes\Validate;
use Illuminate\Support\Facades\Storage;

class UploadPhoto extends Component
{
    use WithFileUploads;

    #[Validate('required|image|mimes:jpeg,png,jpg,gif|max:1024')] // 1MB Max, only image types
    public $photo = null;
    public $uploadedPhotos = [];

    public function mount()
    {
        $this->loadUploadedPhotos();
    }

    public function updatedPhoto()
    {
        $this->validateOnly('photo');
    }

    public function savePhoto()
    {
        $this->validate();

        try {
            $path = $this->photo->store('photos', 'public');
            
            if (!$path) {
                session()->flash('error', 'Failed to store the photo.');
                return;
            }
            $this->reset('photo');
            
            $this->loadUploadedPhotos();

            session()->flash('message', 'Photo uploaded successfully!');
        } catch (\Exception $e) {
            session()->flash('error', 'Error uploading photo: ' . $e->getMessage());
        }
    }

    protected function loadUploadedPhotos()
    {
        try {
            $files = Storage::disk('public')->files('photos');
            $this->uploadedPhotos = array_map(function($file) {
                return [
                    'path' => $file,
                    'url' => asset('storage/' . $file)
                ];
            }, $files);
        } catch (\Exception $e) {
            session()->flash('error', 'Error loading photos: ' . $e->getMessage());
        }
    }

    public function render()
    {
        return view('livewire.upload-photo');
    }
}
