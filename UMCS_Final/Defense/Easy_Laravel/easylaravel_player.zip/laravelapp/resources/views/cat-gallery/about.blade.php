@extends('cat-gallery.layout')

@section('content')
    <div class="max-w-3xl mx-auto">
        <h1 class="text-4xl font-bold text-gray-800 mb-8 text-center">About Cat Gallery</h1>
        
        <div class="bg-white rounded-lg shadow-lg p-8">
            <div class="mb-8">
                <h2 class="text-2xl font-semibold text-gray-800 mb-4">Our Mission</h2>
                <p class="text-gray-600 leading-relaxed">
                    Cat Gallery is dedicated to bringing joy to cat lovers everywhere by showcasing the most adorable and unique cats from around the world. We believe that every cat has a story to tell and deserves to be celebrated.
                </p>
            </div>

            <div class="mb-8">
                <h2 class="text-2xl font-semibold text-gray-800 mb-4">Featured Cats</h2>
                <p class="text-gray-600 leading-relaxed">
                    Our gallery features a variety of cats, each with their own unique personality and charm. From the playful Neo to the elegant Bella, we showcase cats of all types and temperaments.
                </p>
            </div>

            <div class="mb-8">
                <h2 class="text-2xl font-semibold text-gray-800 mb-4">Image Credits</h2>
                <p class="text-gray-600 leading-relaxed">
                    All cat images are provided by PlaceCats.com, a wonderful service that offers placeholder images of cats for use in designs and development. We're grateful for their contribution to making the internet a more feline-friendly place.
                </p>
            </div>

            <div class="text-center">
                <a href="{{ route('cat-gallery.gallery') }}" class="inline-block bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition duration-300">
                    Explore Our Gallery
                </a>
            </div>
        </div>
    </div>
@endsection 