@extends('cat-gallery.layout')

@section('content')
    <h1 class="text-4xl font-bold text-gray-800 mb-8 text-center">Our Cat Gallery</h1>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        @foreach($cats as $cat)
            <div class="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition duration-300">
                <img src="{{ $cat['url'] }}" alt="{{ $cat['name'] }}" class="w-full h-48 object-cover">
                <div class="p-4">
                    <h3 class="text-xl font-semibold text-gray-800">{{ $cat['name'] }}</h3>
                    <div class="mt-2">
                        <a href="{{ $cat['url'] }}" target="_blank" class="text-blue-500 hover:text-blue-700">
                            View Full Image
                        </a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>

    <div class="mt-8 text-center">
        <p class="text-gray-600">
            All images are provided by <a href="https://placecats.com" target="_blank" class="text-blue-500 hover:text-blue-700">PlaceCats.com</a>
        </p>
    </div>
@endsection 