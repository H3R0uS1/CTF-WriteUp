@extends('cat-gallery.layout')

@section('content')
    <div class="text-center mb-12">
        <h1 class="text-4xl font-bold text-gray-800 mb-4">Welcome to Cat Gallery</h1>
        <p class="text-xl text-gray-600">Discover the most adorable cats on the internet</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <img src="https://placecats.com/neo/400/300" alt="Neo" class="w-full h-64 object-cover">
            <div class="p-4">
                <h3 class="text-xl font-semibold text-gray-800">Neo</h3>
                <p class="text-gray-600">The coolest cat in town</p>
            </div>
        </div>
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <img src="https://placecats.com/millie/400/300" alt="Millie" class="w-full h-64 object-cover">
            <div class="p-4">
                <h3 class="text-xl font-semibold text-gray-800">Millie</h3>
                <p class="text-gray-600">The sweetest companion</p>
            </div>
        </div>
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <img src="https://placecats.com/bella/400/300" alt="Bella" class="w-full h-64 object-cover">
            <div class="p-4">
                <h3 class="text-xl font-semibold text-gray-800">Bella</h3>
                <p class="text-gray-600">The elegant beauty</p>
            </div>
        </div>
    </div>

    <div class="mt-12 text-center">
        <a href="{{ route('cat-gallery.gallery') }}" class="inline-block bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition duration-300">
            View All Cats
        </a>
    </div>
@endsection 