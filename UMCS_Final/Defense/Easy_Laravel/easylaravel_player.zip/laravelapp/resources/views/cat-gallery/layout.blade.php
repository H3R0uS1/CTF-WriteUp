<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cat Gallery</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gray-100">
    <nav class="bg-white shadow-lg">
        <div class="max-w-6xl mx-auto px-4">
            <div class="flex justify-between">
                <div class="flex space-x-7">
                    <div>
                        <a href="{{ route('cat-gallery.home') }}" class="flex items-center py-4">
                            <span class="font-semibold text-gray-500 text-lg">Cat Gallery</span>
                        </a>
                    </div>
                    <div class="hidden md:flex items-center space-x-1">
                        <a href="{{ route('cat-gallery.home') }}" class="py-4 px-2 text-gray-500 hover:text-gray-900">Home</a>
                        <a href="{{ route('cat-gallery.about') }}" class="py-4 px-2 text-gray-500 hover:text-gray-900">About</a>
                        <a href="{{ route('cat-gallery.gallery') }}" class="py-4 px-2 text-gray-500 hover:text-gray-900">Gallery</a>
                        @auth
                            <a href="{{ route('cat-profiles.index') }}" class="py-4 px-2 text-gray-500 hover:text-gray-900">Cat Profiles</a>
                            @if(auth()->user()->is_admin)
                                <a href="{{ route('upload') }}" class="py-4 px-2 text-gray-500 hover:text-gray-900">Upload</a>
                            @endif
                        @endauth
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    @auth
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <button type="submit" class="text-gray-500 hover:text-gray-900">Logout</button>
                        </form>
                    @else
                        <a href="{{ route('login') }}" class="text-gray-500 hover:text-gray-900">Login</a>
                        <a href="{{ route('register') }}" class="text-gray-500 hover:text-gray-900">Register</a>
                    @endauth
                </div>
            </div>
        </div>
    </nav>

    <main class="max-w-6xl mx-auto px-4 py-8">
        @yield('content')
    </main>

    <footer class="bg-white shadow-lg mt-8">
        <div class="max-w-6xl mx-auto px-4 py-4">
            <p class="text-center text-gray-500">© 2024 Cat Gallery. All rights reserved.</p>
        </div>
    </footer>
</body>
</html> 