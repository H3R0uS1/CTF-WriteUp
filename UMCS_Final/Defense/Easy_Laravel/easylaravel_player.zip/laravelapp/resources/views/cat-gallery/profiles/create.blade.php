@extends('cat-gallery.layout')

@section('content')
<div class="min-h-screen bg-gray-50 py-12">
    <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <!-- Form Header -->
            <div class="bg-gradient-to-r from-blue-500 to-blue-600 px-6 py-8">
                <h1 class="text-3xl font-bold text-white">Create New Cat Profile</h1>
                <p class="mt-2 text-blue-100">Share your feline friend with the world!</p>
            </div>

            <!-- Form Content -->
            <div class="p-6">
                @if($errors->any())
                    <div class="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded">
                        <div class="flex">
                            <div class="flex-shrink-0">
                                <svg class="h-5 w-5 text-red-500" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                                </svg>
                            </div>
                            <div class="ml-3">
                                <h3 class="text-sm font-medium text-red-800">There were some errors with your submission</h3>
                                <div class="mt-2 text-sm text-red-700">
                                    <ul class="list-disc pl-5 space-y-1">
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif

                <form action="{{ route('cat-profiles.store') }}" method="POST" enctype="multipart/form-data" class="space-y-8">
                    @csrf

                    <!-- Basic Information Section -->
                    <div class="space-y-6">
                        <h2 class="text-xl font-semibold text-gray-900">Basic Information</h2>
                        
                        <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
                            <div>
                                <label for="name" class="block text-sm font-medium text-gray-700">Cat's Name *</label>
                                <div class="mt-1 relative rounded-md shadow-sm">
                                    <input type="text" name="name" id="name" required
                                        class="block w-full rounded-md border-gray-300 pl-3 pr-10 py-2 focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                                        value="{{ old('name') }}"
                                        placeholder="e.g., Whiskers">
                                </div>
                            </div>

                            <div>
                                <label for="breed" class="block text-sm font-medium text-gray-700">Breed</label>
                                <div class="mt-1 relative rounded-md shadow-sm">
                                    <input type="text" name="breed" id="breed"
                                        class="block w-full rounded-md border-gray-300 pl-3 pr-10 py-2 focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                                        value="{{ old('breed') }}"
                                        placeholder="e.g., Siamese">
                                </div>
                            </div>

                            <div>
                                <label for="age" class="block text-sm font-medium text-gray-700">Age</label>
                                <div class="mt-1 relative rounded-md shadow-sm">
                                    <input type="number" name="age" id="age" min="0"
                                        class="block w-full rounded-md border-gray-300 pl-3 pr-10 py-2 focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                                        value="{{ old('age') }}"
                                        placeholder="e.g., 3">
                                </div>
                            </div>
                        </div>

                        <div>
                            <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                            <div class="mt-1">
                                <textarea name="description" id="description" rows="4"
                                    class="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                                    placeholder="Tell us about your cat's personality, habits, and any special characteristics...">{{ old('description') }}</textarea>
                            </div>
                        </div>
                    </div>

                    <!-- Photos Section -->
                    <div class="space-y-6">
                        <h2 class="text-xl font-semibold text-gray-900">Photos</h2>

                        <div class="space-y-4">
                            <div>
                                <label for="profile_picture" class="block text-sm font-medium text-gray-700">Profile Picture</label>
                                <div class="mt-1">
                                    <input type="file" name="profile_picture" id="profile_picture" accept="image/*"
                                        class="block w-full text-sm text-gray-500
                                        file:mr-4 file:py-2 file:px-4
                                        file:rounded-md file:border-0
                                        file:text-sm file:font-semibold
                                        file:bg-blue-50 file:text-blue-700
                                        hover:file:bg-blue-100">
                                    <p class="mt-1 text-xs text-gray-500">PNG, JPG, GIF up to 2MB</p>
                                </div>
                            </div>

                            <div>
                                <label for="photos" class="block text-sm font-medium text-gray-700">Additional Photos</label>
                                <div class="mt-1">
                                    <input type="file" name="photos[]" id="photos" accept="image/*" multiple
                                        class="block w-full text-sm text-gray-500
                                        file:mr-4 file:py-2 file:px-4
                                        file:rounded-md file:border-0
                                        file:text-sm file:font-semibold
                                        file:bg-blue-50 file:text-blue-700
                                        hover:file:bg-blue-100">
                                    <p class="mt-1 text-xs text-gray-500">PNG, JPG, GIF up to 2MB each</p>
                                </div>
                            </div>

                            <div>
                                <label for="captions" class="block text-sm font-medium text-gray-700">Photo Captions</label>
                                <p class="text-sm text-gray-500 mb-2">Add captions for your photos (one per line)</p>
                                <div class="mt-1">
                                    <textarea name="captions[]" id="captions" rows="4"
                                        class="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                                        placeholder="Add captions for your photos...">{{ old('captions') ? implode("\n", old('captions')) : '' }}</textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Form Actions -->
                    <div class="flex justify-end space-x-4 pt-6">
                        <a href="{{ route('cat-profiles.index') }}"
                            class="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Cancel
                        </a>
                        <button type="submit" 
                            class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Create Profile
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection 