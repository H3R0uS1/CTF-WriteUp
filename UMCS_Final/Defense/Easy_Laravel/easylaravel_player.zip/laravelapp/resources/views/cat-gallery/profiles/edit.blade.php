@extends('cat-gallery.layout')

@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="max-w-2xl mx-auto">
        <h1 class="text-3xl font-bold mb-8">Edit Cat Profile</h1>

        @if($errors->any())
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('cat-profiles.update', $cat) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
            @csrf
            @method('PUT')

            <div>
                <label for="name" class="block text-sm font-medium text-gray-700">Name *</label>
                <input type="text" name="name" id="name" required
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    value="{{ old('name', $cat->name) }}">
            </div>

            <div>
                <label for="breed" class="block text-sm font-medium text-gray-700">Breed</label>
                <input type="text" name="breed" id="breed"
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    value="{{ old('breed', $cat->breed) }}">
            </div>

            <div>
                <label for="age" class="block text-sm font-medium text-gray-700">Age</label>
                <input type="number" name="age" id="age" min="0"
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    value="{{ old('age', $cat->age) }}">
            </div>

            <div>
                <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                <textarea name="description" id="description" rows="4"
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">{{ old('description', $cat->description) }}</textarea>
            </div>

            <div>
                <label for="profile_picture" class="block text-sm font-medium text-gray-700">Profile Picture</label>
                @if($cat->profile_picture)
                    <div class="mt-2 mb-4">
                        <img src="{{ Storage::url($cat->profile_picture) }}" alt="Current profile picture" class="w-32 h-32 object-cover rounded-lg">
                    </div>
                @endif
                <input type="file" name="profile_picture" id="profile_picture" accept="image/*"
                    class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
            </div>

            <div>
                <label for="photos" class="block text-sm font-medium text-gray-700">Additional Photos</label>
                @if($cat->photos->isNotEmpty())
                    <div class="mt-2 mb-4 grid grid-cols-3 gap-4">
                        @foreach($cat->photos as $photo)
                            <div class="relative">
                                <img src="{{ Storage::url($photo->photo_path) }}" alt="Cat photo" class="w-full h-32 object-cover rounded-lg">
                                @if($photo->caption)
                                    <div class="mt-1 text-sm text-gray-500 truncate">{{ $photo->caption }}</div>
                                @endif
                            </div>
                        @endforeach
                    </div>
                @endif
                <input type="file" name="photos[]" id="photos" accept="image/*" multiple
                    class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
                <p class="mt-1 text-sm text-gray-500">You can select multiple photos to add</p>
            </div>

            <div>
                <label for="captions" class="block text-sm font-medium text-gray-700">New Photo Captions</label>
                <p class="text-sm text-gray-500 mb-2">Add captions for your new photos (one per line)</p>
                <textarea name="captions[]" id="captions" rows="4"
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">{{ old('captions') ? implode("\n", old('captions')) : '' }}</textarea>
            </div>

            <div class="flex items-center">
                <input type="checkbox" name="is_public" id="is_public" value="1" {{ old('is_public', $cat->is_public) ? 'checked' : '' }}
                    class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                <label for="is_public" class="ml-2 block text-sm text-gray-700">Make profile public</label>
            </div>

            <div class="flex justify-end space-x-4">
                <a href="{{ route('cat-profiles.show', $cat) }}"
                    class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                    Cancel
                </a>
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Update Profile
                </button>
            </div>
        </form>
    </div>
</div>
@endsection 