@extends('cat-gallery.layout')

@section('content')
<div class="min-h-screen bg-gray-50 py-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-gray-900">Cat Profiles</h1>
            <a href="{{ route('cat-profiles.create') }}" 
                class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                Create New Profile
            </a>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            @forelse($cats as $cat)
                <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                    <div class="aspect-w-16 aspect-h-9">
                        @if($cat->profile_picture)
                            <img src="{{ asset('storage/' . $cat->profile_picture) }}" 
                                alt="{{ $cat->name }}" 
                                class="w-full h-48 object-cover">
                        @else
                            <div class="w-full h-48 bg-gray-200 flex items-center justify-center">
                                <span class="text-gray-500">No profile picture</span>
                            </div>
                        @endif
                    </div>
                    <div class="p-4">
                        <h2 class="text-xl font-semibold text-gray-900 mb-2">{{ $cat->name }}</h2>
                        <div class="space-y-1">
                            <p class="text-sm text-gray-600">
                                <span class="font-medium">Breed:</span> {{ $cat->breed ?: 'Unknown breed' }}
                            </p>
                            <p class="text-sm text-gray-600">
                                <span class="font-medium">Age:</span> {{ $cat->age ? $cat->age . ' years old' : 'Age unknown' }}
                            </p>
                            @if($cat->description)
                                <p class="text-sm text-gray-600 line-clamp-2">{{ $cat->description }}</p>
                            @endif
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-span-full text-center py-12">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
                    </svg>
                    <h3 class="mt-2 text-sm font-medium text-gray-900">No cat profiles yet</h3>
                    <p class="mt-1 text-sm text-gray-500">Get started by creating a new cat profile.</p>
                </div>
            @endforelse
        </div>
    </div>
</div>
@endsection 