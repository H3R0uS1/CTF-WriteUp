<div class="max-w-7xl mx-auto">
    <div class="text-center mb-12">
        <h1 class="text-4xl font-bold text-gray-900 mb-4">Photo Library</h1>
        <p class="text-lg text-gray-600">Upload your cat photos and manage them</p>
    </div>

    @if (session()->has('debug'))
        <div class="rounded-md bg-yellow-50 p-4 mb-8">
            <div class="flex">
                <div class="flex-shrink-0">
                    <svg class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                    </svg>
                </div>
                <div class="ml-3">
                    <pre class="text-sm text-yellow-800 whitespace-pre-wrap">{{ session('debug') }}</pre>
                </div>
            </div>
        </div>
    @endif

    <div class="bg-white rounded-lg shadow-lg p-6 mb-8">
        <form wire:submit.prevent="savePhoto" enctype="multipart/form-data">
            <div
                x-data="{ isDragging: false }"
                x-on:dragover.prevent="isDragging = true"
                x-on:dragleave.prevent="isDragging = false"
                x-on:drop.prevent="
                    isDragging = false;
                    $refs.photoInput.files = $event.dataTransfer.files;
                    $refs.photoInput.dispatchEvent(new Event('change'))
                "
                :class="{ 'border-blue-500 bg-blue-50': isDragging }"
                class="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center"
            >
                <div class="space-y-4">
                    <svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                        <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <div class="text-gray-600">
                        <label for="photo" class="cursor-pointer">
                            <span class="font-medium text-blue-600 hover:text-blue-500">Click to upload</span> or drag and drop
                        </label>
                        <input id="photo" x-ref="photoInput" type="file" wire:model="photo" class="hidden" accept="image/*">
                    </div>
                    <p class="text-xs text-gray-500">PNG, JPG, GIF up to 1MB</p>
                </div>
            </div>

            @if($photo)
                <div class="mt-4">
                    <div class="flex mb-2 items-center justify-between">
                        <span class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200">Selected File</span>
                        <span class="text-xs font-semibold inline-block text-blue-600">{{ $photo->getClientOriginalName() }}</span>
                    </div>
                </div>
            @endif

            <div class="mt-4 text-center">
                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">Upload Photo</button>
            </div>
        </form>
    </div>

    @error('photo')
        <div class="rounded-md bg-red-50 p-4 mb-8">
            <div class="flex">
                <svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                </svg>
                <p class="ml-3 text-sm font-medium text-red-800">{{ $message }}</p>
            </div>
        </div>
    @enderror

    @if(session()->has('message'))
        <div class="rounded-md bg-green-50 p-4 mb-8">
            <div class="flex">
                <svg class="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                </svg>
                <p class="ml-3 text-sm font-medium text-green-800">{{ session('message') }}</p>
            </div>
        </div>
    @endif

    @if(count($uploadedPhotos) > 0)
        <div class="mt-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Your Photos</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                @foreach($uploadedPhotos as $photo)
                    <div class="bg-white rounded-lg shadow-md overflow-hidden">
                        <img src="{{ $photo['url'] }}" alt="Uploaded photo" class="w-full h-48 object-cover">
                        <div class="p-4">
                            <p class="text-sm text-gray-500 truncate">{{ basename($photo['path']) }}</p>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    @endif
</div>
