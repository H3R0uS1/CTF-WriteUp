@extends('cat-gallery.layout')

@section('content')
    <livewire:upload-photo />
@endsection 