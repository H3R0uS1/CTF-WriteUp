#!/bin/sh

# Set up storage permissions and link
mkdir -p storage/app/public storage/framework/{sessions,views,cache} storage/app/public/cat-profiles storage/app/public/cat-photos
chown -R www-data:www-data storage bootstrap/cache
chmod -R 775 storage bootstrap/cache

# Remove existing storage link if it exists
rm -f public/storage

# Create storage link with proper permissions
php artisan storage:link
chown -h www-data:www-data public/storage
chmod -R 775 public/storage

# Ensure cat profile directories have proper permissions
chmod -R 775 storage/app/public/cat-profiles storage/app/public/cat-photos
chown -R www-data:www-data storage/app/public/cat-profiles storage/app/public/cat-photos

# Generate application key if not set or is placeholder
if [ -z "$(grep '^APP_KEY=' .env)" ] || [ "$(grep '^APP_KEY=' .env)" = "APP_KEY=base64:your_key_here" ]; then
    php artisan key:generate --force
fi

# Reset database and migrations
rm -f database/database.sqlite
touch database/database.sqlite
chown www-data:www-data database/database.sqlite
chmod 664 database/database.sqlite

# Run migrations and seeders
php artisan migrate:fresh --force
php artisan db:seed --class=AdminUserSeeder

echo "UMCS{FAKE_FLAG}" > /flag.txt
chown root:root /flag.txt
chmod 444 /flag.txt

# Start PHP-FPM
php-fpm &

# Build assets for production
cd /var/www && \
npm run build

# Start Nginx
exec nginx -g "daemon off;"