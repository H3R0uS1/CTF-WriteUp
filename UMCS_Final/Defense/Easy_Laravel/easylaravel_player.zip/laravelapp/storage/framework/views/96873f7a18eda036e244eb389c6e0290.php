<div>
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div><?php echo e(session('message')); ?></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <form wire:submit.prevent="upload">
        <input type="file" wire:model="photo">
        <button type="submit">Uplsssoad</button>
    </form>
</div>
<?php /**PATH /var/www/resources/views/livewire/upload-photo.blade.php ENDPATH**/ ?>