import { defineConfig } from 'vite'
import laravel from 'laravel-vite-plugin'

export default defineConfig({
  plugins: [
    laravel({
      input: ['resources/css/app.css','resources/js/app.js'],
      refresh: true,
    }),
  ],
  server: {
    host: '0.0.0.0',
    port: process.env.VITE_DEV_SERVER_PORT || 8080,
    strictPort: true,
    hmr: {
      host: process.env.VITE_DEV_SERVER_HOST || 'localhost',
      protocol: 'ws',
    },
  },
  build: {
    rollupOptions: {
      external: ['alpinejs', 'livewire/livewire'],
      output: {
        manualChunks: {
          vendor: ['axios'],
        },
      },
    },
  },
  optimizeDeps: {
    include: ['axios'],
    exclude: ['alpinejs', 'livewire/livewire'],
  },
})
