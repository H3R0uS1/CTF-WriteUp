const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const path = require('path');
const rateLimit = require('express-rate-limit');
const { visit } = require('./bot/bot');
const crypto = require('crypto');

const app = express();
const port = 7189;

const secretKey = crypto.randomBytes(32).toString('hex');

const botCredentials = {
    username: `bot_${crypto.randomBytes(4).toString('hex')}`,
    password: crypto.randomBytes(16).toString('hex')
};

const reportLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 5
});

const db = new sqlite3.Database('notes.db', (err) => {
    if (err) {
        console.log(222)
        process.exit(1);
    }
});

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_note_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        user_id INTEGER NOT NULL,
        UNIQUE(user_id, user_note_id),
        FOREIGN KEY(user_id) REFERENCES users(id)
    )`);

    bcrypt.hash(botCredentials.password, 10, (err, hash) => {
        if (err) {
            console.log(222)
            process.exit(1);
        }
        
        db.run('REPLACE INTO users (username, password) VALUES (?, ?)',
            [botCredentials.username, hash],
            function(err) {
                if (err) {
                    console.log(222)
                    process.exit(1);
                }
                
                const server = app.listen(port, '0.0.0.0', () => {
                    console.log(`Server running at http://0.0.0.0:${port}`);
                });
            }
        );
    });
});

process.on('SIGINT', () => {
    db.close((err) => {
        console.log(333)
        process.exit(0);
    });
});

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({
    secret: secretKey,
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false,
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000
    }
}));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const requireAuth = (req, res, next) => {
    if (req.session.userId) {
        next();
    } else {
        res.redirect('/login');
    }
};

app.get('/', (req, res) => {
    res.render('index', { user: req.session.userId ? true : false });
});

app.get('/register', (req, res) => {
    res.render('register');
});

app.post('/register', (req, res) => {
    const { username, password } = req.body;
    
    bcrypt.hash(password, 10, (err, hash) => {
        if (err) {
            return res.redirect('/register');
        }

        db.run('INSERT INTO users (username, password) VALUES (?, ?)', 
            [username, hash], 
            function(err) {
                if (err) {
                    return res.redirect('/register');
                }
                res.redirect('/login');
            }
        );
    });
});

app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;

    db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
        if (err) {
            return res.redirect('/login');
        }
        if (!user) {
            return res.redirect('/login');
        }

        bcrypt.compare(password, user.password, (err, result) => {
            if (err) {
                return res.redirect('/login');
            }
            if (!result) {
                return res.redirect('/login');
            }

            req.session.userId = user.id;
            res.redirect('/dashboard');
        });
    });
});

app.get('/dashboard', requireAuth, (req, res) => {
    db.get('SELECT * FROM users WHERE id = ?', [req.session.userId], (err, user) => {
        if (err) {
            return res.status(500).send('Error fetching user');
        }
        
        db.all('SELECT * FROM notes WHERE user_id = ? ORDER BY id DESC', [req.session.userId], (err, notes) => {
            if (err) {
                return res.status(500).send('Error fetching notes');
            }
            res.render('dashboard', { user: true, notes: notes });
        });
    });
});

app.post('/dashboard', requireAuth, (req, res) => {
    const { content } = req.body;

    db.get('SELECT MAX(user_note_id) as max_id FROM notes WHERE user_id = ?', 
        [req.session.userId], 
        (err, result) => {
            if (err) {
                return res.redirect('/dashboard');
            }

            const nextNoteId = (result.max_id || 0) + 1;

            db.run('INSERT INTO notes (user_note_id, content, user_id) VALUES (?, ?, ?)',
                [nextNoteId, content, req.session.userId],
                function(err) {
                    if (err) {
                        return res.redirect('/dashboard');
                    }
                    res.redirect('/dashboard');
                }
            );
        }
    );
});

app.post('/notes/:id/delete', requireAuth, (req, res) => {
    const noteId = req.params.id;
    const userId = req.session.userId;

    db.run('DELETE FROM notes WHERE user_note_id = ? AND user_id = ?',
        [noteId, userId],
        function(err) {
            if (err) {
                return res.status(500).send('Error deleting note');
            }
            if (this.changes === 0) {
                return res.status(404).send('Note not found');
            }
            res.redirect('/dashboard');
        }
    );
});

app.get('/notes/:id', requireAuth, (req, res) => {
    const noteId = req.params.id;
    const userId = req.session.userId;
    const isUnsafe = req.session.allowUnsafe === true;

    db.get('SELECT * FROM notes WHERE user_note_id = ? AND user_id = ?', [noteId, userId], (err, note) => {
        if (err) {
            return res.status(500).send('Error fetching note');
        }
        if (!note) {
            return res.status(404).send('Note not found');
        }
        res.render('view_note', { user: true, note: note, isUnsafe: isUnsafe });
    });
});

app.post('/prefs/unsafe', requireAuth, (req, res) => {
    req.session.allowUnsafe = req.body.enable === '1';
    res.redirect(`/notes/${req.body.id}`);
});

app.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

app.get('/report', (req, res) => {
    res.sendFile(path.join(__dirname, 'static', 'report.html'));
});

app.post('/report', reportLimiter, (req, res) => {
    const url = req.body.input;

    if (!url) {
        return res.status(400).send('Error: Input is required!');
    }

    (async () => {
        try {
            visit(url, botCredentials);
            res.send('Bot is visiting the URL');
        } catch (err) {
            res.status(400).send(`Error: ${err.message}`);
        }
    })();
});

app.use((err, req, res, next) => {
    res.status(500).send('Something broke!');
}); 