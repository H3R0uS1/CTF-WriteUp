const puppeteer = require("puppeteer");

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function visit(input, botCreds) {
    let browser;
    // !important, the bot is using 127.0.0.1:7189 to get into the application :)
    const baseUrl = "http://127.0.0.1:7189"
    try {
        
        const url = input;
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            throw new Error('Invalid URL format. Please use http:// or https:// URLs only.');
        }
        
        const flag = "UMCS{fake_flag}";
        
        browser = await puppeteer.launch({
            headless: true,
            executablePath: '/usr/bin/google-chrome-stable',
            args: [
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--js-flags=--noexpose_wasm,--jitless",
            ],
        });

        let page = await browser.newPage();
        
        await page.goto(`${baseUrl}/register`, { timeout: 5000, waitUntil: 'domcontentloaded' });
        await sleep(1000);
        
        await page.type('input[name="username"]', botCreds.username);
        await page.type('input[name="password"]', botCreds.password);
        await page.click('button[type="submit"]');
        
        await sleep(2000);
        
        await page.goto(`${baseUrl}/login`, { timeout: 5000, waitUntil: 'domcontentloaded' });
        await sleep(1000);
        
        await page.type('input[name="username"]', botCreds.username);
        await page.type('input[name="password"]', botCreds.password);
        await page.click('button[type="submit"]');
        
        await sleep(2000);

        await page.goto(`${baseUrl}/dashboard`, { timeout: 5000, waitUntil: 'domcontentloaded' });
        await sleep(1000);
        
        await page.type('textarea[name="content"]', flag);
        await page.click('button[type="submit"]');
        
        await sleep(2000);
        
        await page.goto(url, { timeout: 5000, waitUntil: 'domcontentloaded' });
        await sleep(3000);
        
    } catch (err) {
        throw new Error(err.message);
    } finally {
        if (browser) await browser.close();
    }
}

module.exports = { visit };